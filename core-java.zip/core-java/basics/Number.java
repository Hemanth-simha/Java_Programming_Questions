package basics;

public class Number {
	
	public static void main(String[] args) {
		byte n = 126;
	
		System.out.println("Sum: "+ n);
		n++;
		System.out.println("Sum: "+ n);
		n++;
		System.out.println("Sum: "+ n);
		n++;
		System.out.println("Sum: "+ n);
		
	}
}
