/*
 * Print hello world without semicolon(;)
 *  
 */

class helloWithoutSemi{
    
    public static void main(String[] args){
        /**********Method1**************************************/
    if(System.out.printf("Hello world")!=null){
            /*
            Here i'm using printf() instead of println().
            because println() return type is "void". But printf() 
            returns PrintStream object.
            when control comes into if() then it prints the message.          
            
            */
        }
    /**********Method2**************************************/
    //for(System.out.printf("Hello world");;){}
    }
}