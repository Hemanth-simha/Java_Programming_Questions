/**
 *
 * @author Divyanshu
 */
import java.util.Scanner;

public class segmentSieve {

    
    public static void segment(int n) {
        
      //  int limit = (int) (Math.sqrt(n)+1);
        
    }
    public static void main(String[] args) {
           Scanner input = new Scanner(System.in);
           System.out.println("Enter the number: ");
           int n=input.nextInt();
           segment(n);
           input.close();
    }

    
}
